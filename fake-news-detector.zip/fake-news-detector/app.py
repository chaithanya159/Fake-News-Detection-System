"""
Fake News Detector — Streamlit Web App
Run: streamlit run app.py
"""

import os
import streamlit as st
import pandas as pd
import plotly.graph_objects as go

from src.model import predict, load_model, load_data, train_and_evaluate, plot_results

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Fake News Detector",
    page_icon="🔍",
    layout="wide"
)

st.title("🔍 Fake News Detector")
st.markdown("Paste a news headline + article body to check if it's **REAL** or **FAKE**.")

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Setup")

    if st.button("🏋️ Train Model (first run)"):
        with st.spinner("Training 4 models, please wait…"):
            df, le = load_data()
            results, best_name, X_test, y_test = train_and_evaluate(df, le)
            plot_results(results, best_name, X_test, y_test)
        st.success(f"✅ Best model: {best_name}")

    st.markdown("---")
    st.markdown(
        "**How it works:**\n"
        "1. Text is cleaned & stemmed\n"
        "2. TF-IDF converts words to feature vectors\n"
        "3. Best classifier predicts REAL/FAKE\n"
        "4. Confidence score shown as gauge"
    )
    st.markdown("---")
    st.markdown("**Stack:** scikit-learn · NLTK · TF-IDF · Streamlit · Plotly")

# ── Main — Prediction ──────────────────────────────────────────────────────────
col1, col2 = st.columns([2, 1])

with col1:
    st.subheader("📰 Enter News Article")
    title = st.text_input("Headline", placeholder="Enter the news headline here…")
    body  = st.text_area("Article Body", height=200,
                         placeholder="Paste the full article text here…")
    predict_btn = st.button("🔎 Analyse", type="primary", use_container_width=True)

with col2:
    st.subheader("📊 Result")

    if predict_btn:
        if not title and not body:
            st.warning("Please enter a headline or article text.")
        else:
            if not os.path.exists("models/best_model.pkl"):
                st.error("Model not trained yet. Click 'Train Model' in the sidebar first.")
                st.stop()

            text = f"{title} {body}".strip()
            with st.spinner("Analysing…"):
                result = predict(text)

            label = result["label"]
            conf  = result["confidence"]

            # Verdict banner
            if label == "FAKE":
                st.error(f"🚨 **FAKE NEWS** — {conf:.1f}% confidence")
            else:
                st.success(f"✅ **REAL NEWS** — {conf:.1f}% confidence")

            # Gauge chart
            fig = go.Figure(go.Indicator(
                mode="gauge+number",
                value=result["real_prob"],
                title={"text": "Real News Probability (%)"},
                gauge={
                    "axis": {"range": [0, 100]},
                    "bar":  {"color": "#2196F3"},
                    "steps": [
                        {"range": [0,  40], "color": "#ffcccc"},
                        {"range": [40, 60], "color": "#fff3cd"},
                        {"range": [60, 100],"color": "#d4edda"},
                    ],
                    "threshold": {
                        "line":  {"color": "black", "width": 3},
                        "thickness": 0.75,
                        "value": 50
                    }
                }
            ))
            fig.update_layout(height=280, margin=dict(t=40, b=20))
            st.plotly_chart(fig, use_container_width=True)

            st.metric("Fake Probability",  f"{result['fake_prob']:.1f}%")
            st.metric("Real Probability",  f"{result['real_prob']:.1f}%")

# ── Model evaluation section ──────────────────────────────────────────────────
st.markdown("---")
st.subheader("📈 Model Evaluation")

if os.path.exists("models/evaluation_plots.png"):
    st.image("models/evaluation_plots.png", use_column_width=True,
             caption="Accuracy Comparison | Confusion Matrix | ROC Curves")
else:
    st.info("Train the model first to see evaluation plots.")

# ── Try examples ──────────────────────────────────────────────────────────────
st.markdown("---")
st.subheader("💡 Try These Examples")

examples = [
    {
        "label": "🟢 Real News",
        "title": "Scientists develop new vaccine with 94% efficacy in clinical trials",
        "body":  "Researchers at Johns Hopkins University announced the successful completion of Phase 3 clinical trials. The study involved 40,000 participants across 6 countries and was published in The Lancet."
    },
    {
        "label": "🔴 Fake News",
        "title": "Bill Gates microchips found in COVID vaccines, doctor confirms",
        "body":  "A brave doctor has come forward with UNDENIABLE PROOF that Bill Gates has been secretly inserting microchips into vaccines. The mainstream media is hiding this truth from the public!"
    },
]

for ex in examples:
    with st.expander(ex["label"]):
        st.markdown(f"**Headline:** {ex['title']}")
        st.markdown(f"**Text:** {ex['body']}")
        if st.button(f"Analyse this", key=ex["title"]):
            if not os.path.exists("models/best_model.pkl"):
                st.error("Train the model first.")
            else:
                res = predict(f"{ex['title']} {ex['body']}")
                if res["label"] == "FAKE":
                    st.error(f"🚨 FAKE — {res['confidence']:.1f}% confidence")
                else:
                    st.success(f"✅ REAL — {res['confidence']:.1f}% confidence")
