"""
CLI — train the model and test it from the terminal.
Usage:
    python cli.py train
    python cli.py predict "Your news headline and body text here"
"""

import sys
import os

def train():
    from src.model import load_data, train_and_evaluate, plot_results
    df, le = load_data()
    results, best_name, X_test, y_test = train_and_evaluate(df, le)
    plot_results(results, best_name, X_test, y_test)

def predict_text(text):
    from src.model import predict
    if not os.path.exists("models/best_model.pkl"):
        print("[ERROR] Model not trained yet. Run: python cli.py train")
        sys.exit(1)
    result = predict(text)
    print(f"\n{'='*50}")
    print(f"  Verdict    : {result['label']}")
    print(f"  Confidence : {result['confidence']}%")
    print(f"  Fake Prob  : {result['fake_prob']}%")
    print(f"  Real Prob  : {result['real_prob']}%")
    print(f"{'='*50}\n")

def interactive():
    from src.model import predict
    if not os.path.exists("models/best_model.pkl"):
        print("[ERROR] Train the model first: python cli.py train")
        sys.exit(1)
    print("\n🔍 Fake News Detector — Interactive Mode (type 'exit' to quit)\n")
    while True:
        try:
            text = input("Paste news text: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if not text:
            continue
        if text.lower() in {"exit", "quit"}:
            break
        predict_text(text)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        interactive()
    elif sys.argv[1] == "train":
        train()
    elif sys.argv[1] == "predict":
        if len(sys.argv) < 3:
            print("Usage: python cli.py predict \"your text here\"")
        else:
            predict_text(" ".join(sys.argv[2:]))
    else:
        print(f"Unknown command: {sys.argv[1]}")
        print("Usage: python cli.py [train | predict \"text\" | (no args for interactive)]")
