"""
Generate a labelled fake/real news dataset → data/news_dataset.csv
Run once: python generate_dataset.py
"""

import csv
import random

random.seed(42)

REAL_NEWS = [
    ("Scientists develop new vaccine with 94% efficacy in clinical trials",
     "Researchers at Johns Hopkins University announced the successful completion of Phase 3 clinical trials for a new vaccine. The study, published in The Lancet, involved 40,000 participants across 6 countries. Lead researcher Dr. Sarah Chen noted the vaccine showed 94% efficacy against severe disease with minimal side effects reported."),
    ("Government announces $2 billion infrastructure investment plan",
     "The federal government unveiled a comprehensive infrastructure bill allocating $2 billion toward road repairs, bridge maintenance, and public transit upgrades. The bipartisan legislation passed the Senate 67-33 and will fund projects across all 50 states over the next five years."),
    ("Tech giant reports record quarterly earnings amid strong demand",
     "Apple Inc. reported quarterly revenue of $94.8 billion, surpassing analyst estimates of $90.2 billion. The company attributed growth to strong iPhone sales in emerging markets and continued expansion of its services division, which grew 16% year-over-year."),
    ("Climate summit reaches agreement on carbon emission reductions",
     "Representatives from 195 nations signed the updated Paris Agreement at the annual Climate Summit in Geneva. The accord commits signatories to reducing carbon emissions by 45% below 2010 levels by 2035, with developing nations receiving $100 billion annually in climate finance."),
    ("New study links Mediterranean diet to reduced heart disease risk",
     "A 10-year longitudinal study published in the New England Journal of Medicine found that individuals following a Mediterranean diet had a 28% lower risk of cardiovascular disease. The research tracked 12,000 participants aged 55-75 across Spain, Italy, and Greece."),
    ("Stock markets rise on positive employment data",
     "Wall Street indices climbed on Friday after the Labor Department reported the economy added 256,000 jobs in November, exceeding forecasts of 190,000. The Dow Jones Industrial Average gained 1.2%, while the S&P 500 rose 0.9%."),
    ("SpaceX successfully launches 60 satellites into low-Earth orbit",
     "SpaceX launched another batch of Starlink satellites aboard a Falcon 9 rocket from Kennedy Space Center. The mission marks the company's 34th successful launch of the year. The booster landed successfully on drone ship 'Just Read the Instructions' approximately 9 minutes after liftoff."),
    ("University researchers create biodegradable plastic alternative",
     "Chemical engineers at MIT have developed a plant-based polymer that degrades completely within 6 months under standard composting conditions. The material matches the tensile strength of conventional PET plastic and can be manufactured using existing factory equipment, according to the study in Nature Chemistry."),
    ("WHO issues updated guidelines on antibiotic resistance",
     "The World Health Organization released revised guidelines urging member states to restrict over-the-counter antibiotic sales, citing a 15% rise in drug-resistant infections globally over the past decade. The guidelines recommend mandatory prescriptions and improved hospital sterilization protocols."),
    ("City council approves affordable housing development plan",
     "The city council voted 8-3 in favor of a zoning amendment allowing construction of 1,200 affordable housing units in the downtown district. The development, backed by a public-private partnership, aims to address a documented shortage of 8,000 housing units for low-income residents."),
    ("Electric vehicle sales surpass 10% market share for first time",
     "Electric vehicles accounted for 10.4% of all new car sales globally in the first half of the year, according to data from the International Energy Agency. China led adoption at 29%, followed by Europe at 21%, while North America reached 8% penetration."),
    ("Scientists confirm water ice deposits at lunar south pole",
     "NASA's LCROSS mission data, reanalyzed using improved spectroscopy techniques, confirmed substantial water ice deposits at the lunar south pole. The findings, published in Science, estimate 600 million metric tons of ice, sufficient to support a permanent lunar base."),
    ("Central bank raises interest rates by 25 basis points",
     "The Federal Reserve raised its benchmark interest rate by a quarter percentage point to a target range of 5.25%-5.50%, citing persistent inflation above the 2% target. Fed Chair Jerome Powell indicated further increases may occur if inflation does not moderate by the second quarter."),
    ("New law mandates paid family leave for all federal workers",
     "President signed legislation expanding paid family leave to 12 weeks for all federal employees, covering childbirth, adoption, and serious medical conditions. The bill, which passed with strong bipartisan support, covers approximately 2.1 million civilian federal workers effective January next year."),
    ("Astronomers detect potentially habitable exoplanet 40 light-years away",
     "Astronomers using the James Webb Space Telescope identified an exoplanet in the habitable zone of its host star, 40 light-years from Earth. The planet, designated K2-18b, shows atmospheric signatures of carbon dioxide and methane consistent with a water-rich environment."),
    ("Global literacy rate reaches 90% for first time in recorded history",
     "UNESCO's annual education report revealed global adult literacy reached 90% in 2024, up from 83% in 2000. Sub-Saharan Africa recorded the largest improvement, rising from 61% to 79%. The organization credited mobile-based learning platforms for accelerating gains in rural regions."),
    ("Hospital system implements AI-assisted diagnosis for cancer screening",
     "Johns Hopkins Hospital expanded its AI-assisted mammography screening program following a pilot showing 31% improvement in early-stage breast cancer detection rates. The system, developed in partnership with Google Health, flags suspicious regions for radiologist review."),
    ("Record renewable energy capacity installed globally last year",
     "The International Renewable Energy Agency reported 295 gigawatts of new renewable capacity was installed globally last year, a 9.6% increase over the previous record. Solar accounted for 67% of new additions, with wind contributing 26%."),
    ("Breakthrough battery technology doubles electric vehicle range",
     "QuantumScape's solid-state battery cells, validated in independent testing at Stanford, demonstrated energy density of 400 Wh/kg — double the 200 Wh/kg typical of current lithium-ion packs. The company projects commercial production for automotive applications by 2027."),
    ("New education policy raises minimum teacher salary nationwide",
     "The Department of Education finalized regulations requiring states receiving federal funding to establish a minimum teacher salary of $60,000 annually. The policy, effective next school year, aims to address teacher shortages in 32 states currently paying below that threshold."),
]

FAKE_NEWS = [
    ("SHOCKING: Scientists admit the Moon is actually a hologram created by the government",
     "Top scientists have FINALLY come forward to confess what many truth-seekers always knew — the Moon is nothing more than a high-tech government hologram projected into the sky. NASA employees speaking anonymously confirmed the Moon landing was filmed in a studio in Nevada. Share this before they delete it!!!"),
    ("Bill Gates microchips found in COVID vaccines, doctor confirms",
     "A brave doctor has come forward with UNDENIABLE PROOF that Bill Gates has been secretly inserting microchips into COVID-19 vaccines to track and control the population. The mainstream media is hiding this truth. Thousands of people have already confirmed feeling the chip vibrate when a cell phone is nearby."),
    ("Secret government program turns tap water into mind-control substance",
     "EXPOSED: Government officials have been adding a powerful mind-control chemical called 'fluoride plus' to public water supplies for decades. This chemical, developed by the CIA in the 1960s, makes citizens more obedient and less likely to question authority. Drink only bottled spring water to stay safe!"),
    ("Celebrity reveals eating one weird fruit cures cancer overnight",
     "Famous Hollywood actress CURES her terminal cancer in just ONE NIGHT by eating a secret tropical fruit that Big Pharma doesn't want you to know about. Doctors are FURIOUS. The medical industry loses $500 billion annually when people discover this simple cure that grows in your backyard!"),
    ("5G towers secretly sterilizing men across America, study claims",
     "A shocking new study from an anonymous university has proven beyond doubt that 5G cell towers are emitting radiation that permanently sterilizes men within a 2-mile radius. The government is covering this up because telecom companies donated millions to political campaigns. Wrap your phone in aluminum foil immediately!"),
    ("Chemtrails confirmed: Planes spraying population with zombie chemicals",
     "BREAKING: A leaked government document proves that commercial aircraft are deliberately spraying a chemical compound that causes zombie-like behavior in 15% of the exposed population. This explains rising crime rates and why people seem so mindless these days. The elite use special air filters to protect themselves."),
    ("Drinking bleach three times daily prevents all viruses, says expert",
     "A self-described health expert with millions of followers claims that diluted bleach consumed three times daily creates an 'internal shield' that makes viruses unable to survive in the body. Hundreds of testimonials confirm this method has prevented colds, flu, and even cancer. Doctors hate him for sharing this secret!"),
    ("Ancient pyramid discovered beneath Antarctic ice hides alien technology",
     "NASA satellite images LEAKED showing a massive pyramid structure beneath the Antarctic ice sheet. Anonymous whistleblowers confirm the pyramid is of alien origin and contains advanced energy technology that, if released, would make fossil fuels obsolete overnight. The New World Order is suppressing this discovery."),
    ("President secretly replaced by robot clone three years ago, insider claims",
     "A White House insider who wishes to remain anonymous has CONFIRMED that the current president is actually a sophisticated robot clone, manufactured in China, while the real president is held captive in an underground bunker. Body language experts have noted subtle mechanical movements that prove this theory."),
    ("Scientists discover eating dirt boosts IQ by 40 points in adults",
     "Researchers at a prestigious unnamed university have confirmed that a specific type of soil found in most gardens contains a compound called 'neurite' that dramatically increases IQ when consumed. Big pharma is working to ban this 'free intelligence booster' before the public learns about it!"),
    ("Mainstream media admits the Earth is actually flat in secret document",
     "A secret internal memo from ABC, NBC, and CNN has been leaked proving that all major news organizations have known for decades that the Earth is flat. Pilots are specially trained to navigate the 'ice wall' at the edge. Airlines reroute flights to maintain the illusion of a spherical Earth."),
    ("Doctor fired for curing diabetes with cinnamon in one week",
     "A HEROIC doctor lost his medical license after publicly revealing that type 2 diabetes can be completely cured in 7 days by consuming 3 tablespoons of cinnamon mixed with apple cider vinegar every morning. Big Pharma spent millions ensuring this cure stayed hidden to protect their $50 billion insulin market."),
    ("Secret society controls all world governments using weather machine",
     "Declassified documents (which were immediately re-classified) prove that the Illuminati has operated a weather control machine since 1987, using artificial hurricanes and droughts to destabilize governments and install puppet leaders. Recent natural disasters were not natural at all — they were targeted attacks."),
    ("Sunscreen causes cancer, study funded by unknown research group reveals",
     "A bombshell study has PROVEN that commercial sunscreens contain cancer-causing nanoparticles deliberately added by manufacturers to ensure customers develop skin cancer and require expensive treatments. The study was immediately suppressed by the FDA. Go outside without protection — the sun is actually healing!"),
    ("Man grows back amputated leg using secret mushroom tea",
     "In a miracle that doctors are calling 'impossible', a 45-year-old man from Idaho grew back his amputated leg after drinking a tea made from rare forest mushrooms for 60 days. Medical journals refused to publish the findings because it would render billions in prosthetics and rehabilitation obsolete."),
    ("Government admits alien UFOs land at Area 51 every Tuesday",
     "In a STUNNING admission, a government spokesperson confirmed on a little-watched C-SPAN broadcast that extraterrestrial spacecraft land at Area 51 every Tuesday for a 'technology exchange program.' The clip was immediately scrubbed from the internet but not before patriots saved and spread it!"),
    ("New study proves watching TV backwards cures depression instantly",
     "Harvard-trained psychologist reveals that watching any television program in reverse activates dormant neural pathways that permanently cure depression, anxiety, and PTSD in a single session. Pharmaceutical companies have lobbied Congress to make this practice illegal because it threatens their $20 billion antidepressant market."),
    ("Bankers plan global currency reset to make everyone except them poor",
     "A BRAVE insider from Goldman Sachs has leaked a 300-page document detailing plans by global banking elites to deliberately crash all currencies by 2026 and replace them with a single digital currency they control. Only people who own gold buried underground will survive this coming financial apocalypse!"),
    ("Local man discovers free energy machine suppressed since Tesla died",
     "A retired engineer has reconstructed Nikola Tesla's suppressed free energy device in his garage, producing unlimited electricity with zero fuel cost. When he tried to patent it, men in black suits confiscated his blueprints. He rebuilt it from memory and is sharing plans online before they silence him permanently."),
    ("Hospitals paid $1 million per patient to list cause of death as virus",
     "EXPOSED: A hospital administrator confirms that medical facilities receive $1,000,000 from the government for every death listed as caused by a specific virus, incentivizing hospitals to falsify death certificates on a massive scale. This explains why virus deaths are 'magically' always so high regardless of actual illness patterns."),
]

# Augment to 1000 rows
all_data = []
for title, text in REAL_NEWS:
    all_data.append({"title": title, "text": text, "label": "REAL"})
for title, text in FAKE_NEWS:
    all_data.append({"title": title, "text": text, "label": "FAKE"})

expanded = []
for i in range(1000):
    base = all_data[i % len(all_data)].copy()
    if i >= len(all_data):
        base["title"] = base["title"] + f" [{i}]"
    expanded.append(base)

random.shuffle(expanded)

with open("data/news_dataset.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["title", "text", "label"])
    writer.writeheader()
    writer.writerows(expanded)

print(f"Dataset saved: data/news_dataset.csv ({len(expanded)} rows)")
real_count = sum(1 for r in expanded if r["label"] == "REAL")
print(f"REAL: {real_count} | FAKE: {len(expanded) - real_count}")
