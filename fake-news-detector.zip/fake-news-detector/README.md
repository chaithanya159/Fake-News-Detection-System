# 🔍 Fake News Detector

A machine learning system that classifies news articles as **REAL** or **FAKE** using NLP and classical ML algorithms. Built with scikit-learn, NLTK, TF-IDF, and deployed as an interactive Streamlit web app.

---

## 🎯 What it does

Paste any news headline and article body → the model predicts whether it's real or fake with a confidence percentage, displayed as an interactive gauge chart.

---

## 🏗️ How it works

```
Raw Text (headline + body)
        ↓
  Preprocessing
  (lowercase → remove punctuation → remove stopwords → stem)
        ↓
  TF-IDF Vectorisation
  (10,000 features, unigrams + bigrams)
        ↓
  Classifier (best of 4 models)
        ↓
  REAL / FAKE + Confidence %
```

---

## 📊 Models Compared

| Model | Typical Accuracy | Notes |
|---|---|---|
| Logistic Regression | ~96% | Fast, interpretable, strong baseline |
| Naive Bayes | ~93% | Very fast, good for text |
| Random Forest | ~95% | Robust, handles noisy features well |
| Gradient Boosting | ~94% | Slower but strong on tabular features |

The best-performing model is automatically saved and used for predictions.

---

## 🛠️ Tech Stack

| Component | Tool |
|---|---|
| NLP Preprocessing | NLTK (stopwords, stemming) |
| Feature Extraction | TF-IDF (scikit-learn) |
| ML Models | Logistic Regression, Naive Bayes, Random Forest, Gradient Boosting |
| Evaluation | Confusion Matrix, ROC-AUC, 5-fold Cross Validation |
| Web UI | Streamlit + Plotly |
| Visualisation | Matplotlib, Seaborn |

---

## ⚙️ Setup

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/fake-news-detector.git
cd fake-news-detector
```

### 2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Generate dataset
```bash
python generate_dataset.py
```
This creates `data/news_dataset.csv` (1,000 labelled articles).

---

## ▶️ Running

### Train the model
```bash
python cli.py train
```
Trains all 4 models, prints a comparison table, saves the best model, and generates evaluation plots.

### Streamlit Web App
```bash
streamlit run app.py
```
Open [http://localhost:8501](http://localhost:8501)

### Command Line Prediction
```bash
python cli.py predict "Vaccine microchips confirmed by anonymous doctor"
python cli.py           # interactive mode
```

---

## 📁 Project Structure

```
fake-news-detector/
├── app.py                   # Streamlit web UI
├── cli.py                   # Command-line interface
├── generate_dataset.py      # Dataset generator
├── requirements.txt
├── .gitignore
├── data/
│   └── news_dataset.csv     # 1,000 labelled news articles (auto-generated)
├── src/
│   └── model.py             # Full ML pipeline: preprocess → train → evaluate → predict
└── models/                  # Auto-generated after training
    ├── best_model.pkl        # Saved best model
    └── evaluation_plots.png  # Accuracy + Confusion Matrix + ROC curves
```

---

## 📈 Evaluation Metrics

After training, the system generates three visualisations:
- **Accuracy bar chart** — side-by-side comparison of all 4 models
- **Confusion matrix** — true positive / false positive breakdown for the best model
- **ROC curves** — AUC scores for all models on the same axes

---

## 🧪 Example Predictions

| Text | Prediction |
|---|---|
| "Scientists publish vaccine trial results in The Lancet with 94% efficacy" | ✅ REAL |
| "Bill Gates inserting microchips into vaccines confirmed by anonymous doctor!!!" | 🚨 FAKE |
| "Federal Reserve raises interest rates by 25 basis points citing inflation" | ✅ REAL |
| "Moon is a government hologram, NASA whistleblower confesses" | 🚨 FAKE |

---

## 🔧 Customisation

| What to change | Where |
|---|---|
| Use your own dataset | Replace `data/news_dataset.csv` (keep columns: title, text, label) |
| Add more models | Extend `get_pipelines()` in `src/model.py` |
| Change TF-IDF features | Edit `tfidf_params` in `src/model.py` |
| Swap stemmer for lemmatizer | Replace `PorterStemmer` with `WordNetLemmatizer` in `preprocess()` |

---

## 📄 License

MIT License — free to use for personal and commercial projects.
