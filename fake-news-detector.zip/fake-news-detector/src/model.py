"""
Fake News Detection — Core ML Pipeline
=======================================
Trains and evaluates 4 classifiers using TF-IDF features.
Saves the best model to models/best_model.pkl
"""

import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score, roc_curve
)
from sklearn.preprocessing import LabelEncoder

import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import re

# Download required NLTK data
nltk.download("stopwords", quiet=True)
nltk.download("punkt", quiet=True)

os.makedirs("models", exist_ok=True)


# ── Text preprocessing ────────────────────────────────────────────────────────
stemmer = PorterStemmer()
STOPWORDS = set(stopwords.words("english"))

def preprocess(text: str) -> str:
    """Lowercase → remove non-alpha → remove stopwords → stem."""
    text = text.lower()
    text = re.sub(r"[^a-z\s]", "", text)
    tokens = text.split()
    tokens = [stemmer.stem(t) for t in tokens if t not in STOPWORDS and len(t) > 2]
    return " ".join(tokens)


# ── Data loading ──────────────────────────────────────────────────────────────
def load_data(path: str = "data/news_dataset.csv"):
    df = pd.read_csv(path)
    df = df.dropna(subset=["title", "text", "label"])

    # Combine title + text for richer features
    df["combined"] = df["title"] + " " + df["text"]
    df["processed"] = df["combined"].apply(preprocess)

    le = LabelEncoder()
    df["label_enc"] = le.fit_transform(df["label"])   # FAKE=0, REAL=1

    print(f"\n[DATA] Loaded {len(df)} rows")
    print(df["label"].value_counts().to_string())
    return df, le


# ── Model definitions ──────────────────────────────────────────────────────────
def get_pipelines():
    tfidf_params = dict(
        max_features=10_000,
        ngram_range=(1, 2),
        sublinear_tf=True,
        min_df=2
    )
    return {
        "Logistic Regression": Pipeline([
            ("tfidf", TfidfVectorizer(**tfidf_params)),
            ("clf",   LogisticRegression(max_iter=1000, C=1.0, random_state=42))
        ]),
        "Naive Bayes": Pipeline([
            ("tfidf", TfidfVectorizer(**tfidf_params)),
            ("clf",   MultinomialNB(alpha=0.1))
        ]),
        "Random Forest": Pipeline([
            ("tfidf", TfidfVectorizer(**tfidf_params)),
            ("clf",   RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1))
        ]),
        "Gradient Boosting": Pipeline([
            ("tfidf", TfidfVectorizer(**tfidf_params)),
            ("clf",   GradientBoostingClassifier(n_estimators=100, random_state=42))
        ]),
    }


# ── Training & evaluation ─────────────────────────────────────────────────────
def train_and_evaluate(df, le):
    X = df["processed"]
    y = df["label_enc"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    pipelines = get_pipelines()
    results = {}
    best_acc = 0
    best_name = None
    best_pipeline = None

    print("\n" + "="*60)
    print("MODEL COMPARISON")
    print("="*60)

    for name, pipeline in pipelines.items():
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        y_prob = pipeline.predict_proba(X_test)[:, 1]

        acc   = accuracy_score(y_test, y_pred)
        auc   = roc_auc_score(y_test, y_prob)
        cv    = cross_val_score(pipeline, X, y, cv=5, scoring="accuracy").mean()
        report = classification_report(y_test, y_pred,
                                       target_names=le.classes_, output_dict=True)

        results[name] = {
            "pipeline": pipeline,
            "accuracy": acc,
            "auc":      auc,
            "cv_score": cv,
            "y_pred":   y_pred,
            "y_prob":   y_prob,
            "report":   report,
        }

        print(f"\n{name}")
        print(f"  Accuracy  : {acc:.4f}")
        print(f"  ROC-AUC   : {auc:.4f}")
        print(f"  CV (5-fold): {cv:.4f}")
        print(classification_report(y_test, y_pred, target_names=le.classes_))

        if acc > best_acc:
            best_acc = acc
            best_name = name
            best_pipeline = pipeline

    print("="*60)
    print(f"\n✅ Best model: {best_name} (Accuracy: {best_acc:.4f})")

    # Save best model + vectorizer metadata
    with open("models/best_model.pkl", "wb") as f:
        pickle.dump({"model": best_pipeline, "label_encoder": le, "name": best_name}, f)
    print("   Saved to models/best_model.pkl")

    return results, best_name, X_test, y_test


# ── Visualisations ────────────────────────────────────────────────────────────
def plot_results(results, best_name, X_test, y_test):
    os.makedirs("models", exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    # 1 — Accuracy comparison bar chart
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    names = list(results.keys())
    accs  = [results[n]["accuracy"] for n in names]
    aucs  = [results[n]["auc"] for n in names]

    bars = axes[0].bar(names, accs, color=["#2196F3", "#4CAF50", "#FF9800", "#E91E63"])
    axes[0].set_title("Model Accuracy Comparison", fontsize=13, fontweight="bold")
    axes[0].set_ylabel("Accuracy")
    axes[0].set_ylim(0.5, 1.05)
    for bar, acc in zip(bars, accs):
        axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.005,
                     f"{acc:.3f}", ha="center", va="bottom", fontweight="bold")
    axes[0].set_xticklabels(names, rotation=15, ha="right")

    # 2 — Confusion matrix for best model
    cm = confusion_matrix(y_test, results[best_name]["y_pred"])
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=axes[1],
                xticklabels=["FAKE", "REAL"], yticklabels=["FAKE", "REAL"])
    axes[1].set_title(f"Confusion Matrix\n({best_name})", fontsize=13, fontweight="bold")
    axes[1].set_xlabel("Predicted")
    axes[1].set_ylabel("Actual")

    # 3 — ROC curves
    for name, res in results.items():
        fpr, tpr, _ = roc_curve(y_test, res["y_prob"])
        axes[2].plot(fpr, tpr, label=f"{name} (AUC={res['auc']:.3f})", linewidth=2)
    axes[2].plot([0,1], [0,1], "k--", linewidth=1)
    axes[2].set_title("ROC Curves", fontsize=13, fontweight="bold")
    axes[2].set_xlabel("False Positive Rate")
    axes[2].set_ylabel("True Positive Rate")
    axes[2].legend(fontsize=8)

    plt.tight_layout()
    plt.savefig("models/evaluation_plots.png", dpi=150, bbox_inches="tight")
    print("\n   Plots saved to models/evaluation_plots.png")
    plt.close()


# ── Predict helper ────────────────────────────────────────────────────────────
def load_model(path: str = "models/best_model.pkl"):
    with open(path, "rb") as f:
        bundle = pickle.load(f)
    return bundle["model"], bundle["label_encoder"], bundle["name"]


def predict(text: str, model=None, le=None):
    """Predict whether a news article is REAL or FAKE."""
    if model is None:
        model, le, _ = load_model()
    processed = preprocess(text)
    pred  = model.predict([processed])[0]
    proba = model.predict_proba([processed])[0]
    label = le.inverse_transform([pred])[0]
    confidence = max(proba) * 100
    return {
        "label":      label,
        "confidence": round(confidence, 2),
        "fake_prob":  round(proba[0] * 100, 2),
        "real_prob":  round(proba[1] * 100, 2),
    }


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    df, le = load_data()
    results, best_name, X_test, y_test = train_and_evaluate(df, le)
    plot_results(results, best_name, X_test, y_test)
